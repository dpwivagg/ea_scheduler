To run this project :

You should run Simulation.py 
Then input the following line "gibbs query_node evidence_node=state -u #_of_iterations -d #_of_drops" and press enter
Here is an example of the input "gibbs location school=good -u 10000 -d 2000"