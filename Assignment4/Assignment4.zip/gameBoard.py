

class boardObject():
    def __init__(self, type, reward):
        self.type = type
        self.reward = reward

    def getType(self):
        return self.type

    def getReward(self):
        return self.reward




